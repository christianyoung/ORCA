from fpdf import FPDF
import datetime
import pdfGen

fac = ''
aut = ''
today = datetime.date.today()
todayString = today.strftime('%d %B %Y')

def generate(faction, author, path):
	fac = faction
	aut = author
	pdf=PDF('L')
	pdf.alias_nb_pages()
	pdf.add_page()
	pdfGen.stats(pdf,faction,path)
	pdf.add_page()
	pdfGen.fullNetwork(pdf,faction,path)
	pdf.add_page()
	pdfGen.coreAndAss(pdf,faction,path)
	pdf.add_page()
	pdfGen.ecosystem(pdf,faction,path)
	pdf.add_page()
	pdfGen.connectingMem(pdf,faction,path)
	pdfGen.subGroups(pdf,faction,path)
	pdf.output(path+faction+'.pdf','F')

class PDF(FPDF):
        def header(this):
                this.set_font('Helvetica','BU',10)
                this.cell(0,3,'ANALYSIS OF '+fac+' - '+todayString,0,1,'C')
                this.ln()
                this.cell(0,3,'Author: ' + aut,0,1,'C')
                this.set_font('Helvetica','',10)
                this.ln()
                this.ln()

        def footer(this):
                this.set_y(-15)
                this.set_font('Helvetica','',10)
                this.cell(0,10,str(FPDF.page_no(this)),0,0,'C')
	